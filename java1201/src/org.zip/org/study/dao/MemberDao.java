package org.study.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.study.dbconnect.DBConnect;

public class MemberDao {
	
	public MemberDao() {
		System.out.println("기본생성자");
	}
	
	//회원가입 return 정수 1(성공)
	public int inserDo(String userID, String userPw ,int age){
		System.out.print(userID+" "+userPw+" "+age);
		int result=0;
		Connection conn =null; //DB연동 데이터 베이스 연동객체
		PreparedStatement pstm = null;//SQL
		String query = "";
		
		try {
			//1.DB연동
			conn = DBConnect.getConnection();	//prepareStatement
			query = "insert into member(userId,userPw,age) values(?,?,?)";
			pstm = conn.prepareStatement(query); //DB연동, SQL처리
			pstm.setString(1, userID);// setString(인덱스(1~), 값)
			pstm.setString(2, userPw);
			pstm.setInt(3, age);
			
			//실행
			result = pstm.executeUpdate(); //성공이면 1반환
			
		} catch (SQLException e) {
			e.printStackTrace();
		
		}finally {
				try {
					if(conn!=null) conn.close();
					if(pstm!=null) pstm.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}finally {}
		}
		
		return result;
		
		
	}
	
	//회원조회 return 객체(DTO), null
	
	//회원수정 return 정수 1(성공)
	
	//회원탈퇴 return 정수 1(성공)
}
