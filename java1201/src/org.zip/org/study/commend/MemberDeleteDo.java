package org.study.commend;

public class MemberDeleteDo implements Excutecommend {

	@Override
	public void excuteQueryCommend() {
		System.out.println("회원탈퇴");
	}

	

}
