package org.study.commend;

public class MemberSelectDo implements Excutecommend {

	@Override
	public void excuteQueryCommend() {
		System.out.println("회원조회");
	}

	

}
