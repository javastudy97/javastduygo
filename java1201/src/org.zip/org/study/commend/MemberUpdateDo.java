package org.study.commend;

public class MemberUpdateDo implements Excutecommend {

	@Override
	public void excuteQueryCommend() {
		System.out.println("회원수정");
	}

	

}
