package org.study.commend;

public interface Excutecommend {

	void excuteQueryCommend();
}
